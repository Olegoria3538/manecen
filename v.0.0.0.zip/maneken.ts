import {
  AnyObject,
  CheaterType,
  ManecenEvent,
  ManecenStore,
  WatcherType,
} from "./type";

export function manecen<T extends AnyObject = AnyObject>(o: T) {
  const watchers = new Set() as Set<WatcherType<T>>;
  let state = { ...o };

  const getState = () => state;

  const change = (cheater: CheaterType<T>) => {
    state = cheater(state);
    watchers.forEach((x) => x(state));
  };

  const watch = (w: WatcherType<T> | WatcherType<T>[]) => {
    Array.isArray(w) ? w.forEach((x) => watchers.add(x)) : watchers.add(w);
  };

  const on = (ev: ManecenEvent, c: CheaterType<T>) =>
    ev.addSubscription(() => change(c));

  const newObj = { getState, change, watch, on };
  return newObj;
}

export function manecenEvent<T extends AnyObject = AnyObject>() {
  const watchers = new Set() as Set<WatcherType<T>>;
  const watch = (w: WatcherType<T> | WatcherType<T>[]) => {
    Array.isArray(w) ? w.forEach((x) => watchers.add(x)) : watchers.add(w);
  };

  const subscription = new Set() as Set<() => void>;
  const addSubscription = (x: () => void) => {
    subscription.add(x);
  };

  const ev = Object.assign(
    (x: T) => {
      subscription.forEach((f) => f());
      watchers.forEach((f) => f(x));
    },
    {
      watch,
    },
    {
      addSubscription,
    }
  );

  return ev;
}

const store = manecen({ f: 1 });
store.watch((x) => console.log(x));

const event = manecenEvent();
event.watch(() => console.log("это вотч евента"));

store.on(event, (s) => ({ ...s, f: s.f + 3 }));

event({});

import { manecen, manecenEvent } from "../maneken";

export interface AnyObject {
  [k: string]: any;
}

export type WatcherType<T> = (state: T) => void;

export type CheaterType<T> = (state: T) => T;

export type ManecenEvent = ReturnType<typeof manecenEvent>;

export type ManecenStore = ReturnType<typeof manecen>;
